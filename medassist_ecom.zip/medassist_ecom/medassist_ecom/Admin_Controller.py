from django.shortcuts import render
from . import Pool
from django.http import JsonResponse
from django.views.decorators.clickjacking import xframe_options_exempt
@xframe_options_exempt
def Login_Page(request):
    return render(request,"LoginPage.html")
def Logout_Page(request):
    del request.session['ADMIN']
    return render(request,"LoginPage.html")

def Check_Login_Page(request):
    try:
        db,cmd = Pool.ConnectionPooling()
        emailid = request.POST['emailid']
        password = request.POST['password']
        query = "select * from adminlogin where emailid='{0}'and password='{1}'".format(emailid,password)
        print(query)
        cmd.execute(query)
        row=cmd.fetchone()
        if(row):
            request.session['ADMIN']=row
            return render(request, "DashBoard.html" , {"AdminData":row})
        else:
            return render(request, "LoginPage.html",{'message':'Invalid Emailid/Password'})



    except Exception as e:
        return render(request, "LoginPage.html",{'message': 'Something went wrong'})

