
from django.shortcuts import render
from . import Pool
from django.http import JsonResponse
from django.views.decorators.clickjacking import xframe_options_exempt
@xframe_options_exempt

def Picture_Interface(request):
    try:
        admin = request.session['ADMIN']
        return render(request, "PictureInterface.html")
    except Exception as e:
        return render(request, "LoginPage.html")


@xframe_options_exempt

def Submit_Picture(request):
    try:
        db, cmd = Pool.ConnectionPooling()
        categoryname = request.POST['category_name']
        subcategoryname = request.POST['subcategory_name']
        brandname = request.POST['brand_name']
        productname = request.POST['product_name']
        image = request.FILES['picture_icon']
        q = "insert into picture(categoryid,subcategoryid,brandid,productid,picture) values({0},{1},{2},{3},'{4}')".format(
            categoryname, subcategoryname, brandname, productname, image.name)

        F = open("d:/medassist_ecom/assets/" + image.name, 'wb')
        for chunk in image.chunks():
            F.write(chunk)
        F.close()
        cmd.execute(q)
        db.commit()
        db.close()
        return render(request, "PictureInterface.html", {'message': 'True'})
    except Exception as e:
        print("Error:", e)
        return render(request, "PictureInterface.html", {'message': 'False'})
